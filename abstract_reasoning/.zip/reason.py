# coding=utf-8
# Copyright 2018 The DisentanglementLib Authors.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Main training protocol used for computing abstract reasoning scores.

This is the main pipeline for the reasoning step in the paper:
Are Disentangled Representations Helpful for Abstract Visual Reasoning?
Sjoerd van Steenkiste, Francesco Locatello, Juergen Schmidhuber, Olivier Bachem.
NeurIPS, 2019.
https://arxiv.org/abs/1905.12506
"""

import os
import time
import argparse

from abstract_reasoning import models  # pylint: disable=unused-import
from abstract_reasoning import pgm_data
import numpy as np
import tensorflow as tf
import pickle as pkl

def parse_args():
  parser = argparse.ArgumentParser(description='Evaluate Disentanglement Metrics')
  parser.add_argument('--model', type=str, required = True, metavar='M',
                    help='path to saved model files to be evaluated')
  parser.add_argument('--save_path', type=str, default = None, metavar='N',
                    help='Path to save result files')
  parser.add_argument('--seed', type=int, default=10, metavar='S',
                    help='random seed (default: 10)')
  #parser.add_argument('--fairness', action='store_true', default=True)
  return parser.parse_args()
def reason(
    input_dir,
    output_dir = 'trained_rel_nets/',
    model=models.TwoStageModel(),
    num_iterations=100,
    training_steps_per_iteration=1000,
    eval_steps_per_iteration=100,
    random_seed=10,
    batch_size=32,
    name="",
):
  """Trains the estimator and exports the snapshot and the gin config.

  The use of this function requires the gin binding 'dataset.name' to be
  specified if a model is trained from scratch as that determines the data set
  used for training.

  Args:
    input_dir: String with path to directory where the representation function
      is saved.
    output_dir: String with the path where the results should be saved.
    overwrite: Boolean indicating whether to overwrite output directory.
    model: GaussianEncoderModel that should be trained and exported.
    num_iterations: Integer with number of training steps.
    training_steps_per_iteration: Integer with number of training steps per
      iteration.
    eval_steps_per_iteration: Integer with number of validationand test steps
      per iteration.
    random_seed: Integer with random seed used for training.
    batch_size: Integer with the batch size.
    name: Optional string with name of the model (can be used to name models).
  """
  # We do not use the variable 'name'. Instead, it can be used to name results
  # as it will be part of the saved gin config.

  # Create a numpy random state. We will sample the random seeds for training
  # and evaluation from this.
  model_name = input_dir.split('/')[-1]
  random_state = np.random.RandomState(random_seed)
  dataset = pgm_data.get_pgm_dataset(model_name)

  # Set the path to the TFHub embedding if we are training based on a
  # pre-trained embedding..

  # We create a TPUEstimator based on the provided model. This is primarily so
  # that we could switch to TPU training in the future. For now, we train
  # locally on GPUs.
  run_config = tf.contrib.tpu.RunConfig(
      tf_random_seed=random_seed,
      keep_checkpoint_max=1,
      tpu_config=tf.contrib.tpu.TPUConfig(iterations_per_loop=500))
  tpu_estimator = tf.contrib.tpu.TPUEstimator(
      use_tpu=False,
      model_fn=model.model_fn,
      model_dir=os.path.join(output_dir, model_name[:-3], "checkpoint"),
      train_batch_size=batch_size,
      eval_batch_size=batch_size,
      config=run_config)

  # Set up time to keep track of elapsed time in results.
  experiment_timer = time.time()

  # Create a dictionary to keep track of all relevant information.
  validation_scores = []
  test_scores = []
  if os.path.exists(os.path.join(output_dir, model_name[:-3],'accuracy.pkl')):
    a = pkl.load(open(os.path.join(output_dir, model_name[:-3],'accuracy.pkl'),'rb'))
    print(len(a['val']))
    num_iterations = num_iterations - len(a['val'])
    validation_scores = a['val']
    test_scores = a['test']
  print('starting training')
  for i in range(num_iterations):
    steps_so_far = i * training_steps_per_iteration
    # Train the model for the specified steps.
    tpu_estimator.train(
        input_fn=dataset.make_input_fn(random_state.randint(2**32)),
        steps=training_steps_per_iteration)
    # Compute validation scores used for model selection.
    validation_results = tpu_estimator.evaluate(
        input_fn=dataset.make_input_fn(
            random_state.randint(2**32), num_batches=eval_steps_per_iteration))
    validation_scores.append(validation_results["accuracy"])
    # Compute test scores for final results.
    test_results = tpu_estimator.evaluate(
        input_fn=dataset.make_input_fn(
            random_state.randint(2**32), num_batches=eval_steps_per_iteration),
        name="test")
    test_scores.append(test_results["accuracy"])
    print('{} steps\t\tValidation \
      Accuracy: {}, Testing Accuracy: {}'.format(steps_so_far,\
        validation_results['accuracy'], test_results['accuracy']), flush = True)
    with open(os.path.join(output_dir, model_name[:-3], 'accuracy.pkl'), 'wb') as b:
      pkl.dump({'val':validation_scores, 'test':test_scores}, b)
  # Select the best number of steps based on the validation scores and add it as
  # as a special key to the dictionary.
  best_index = np.argmax(validation_scores)
  print('Best test score is:\t', test_scores[best_index])

if __name__ == '__main__':
  args = parse_args()
  tf.logging.set_verbosity(tf.logging.ERROR)
  reason(input_dir = args.model, output_dir = args.save_path, random_seed = args.seed)
